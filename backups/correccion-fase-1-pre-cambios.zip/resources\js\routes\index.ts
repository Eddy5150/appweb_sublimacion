import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: register.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
        registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
        registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    register.form = registerForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
export const catalogo = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: catalogo.url(options),
    method: 'get',
})

catalogo.definition = {
    methods: ["get","head"],
    url: '/catalogo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
catalogo.url = (options?: RouteQueryOptions) => {
    return catalogo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
catalogo.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: catalogo.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
catalogo.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: catalogo.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
    const catalogoForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: catalogo.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
        catalogoForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: catalogo.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CatalogoController::catalogo
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
        catalogoForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: catalogo.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    catalogo.form = catalogoForm
/**
 * @see routes/web.php:36
 * @route '/panel'
 */
export const panel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: panel.url(options),
    method: 'get',
})

panel.definition = {
    methods: ["get","head"],
    url: '/panel',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:36
 * @route '/panel'
 */
panel.url = (options?: RouteQueryOptions) => {
    return panel.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:36
 * @route '/panel'
 */
panel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: panel.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:36
 * @route '/panel'
 */
panel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: panel.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:36
 * @route '/panel'
 */
    const panelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: panel.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:36
 * @route '/panel'
 */
        panelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: panel.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:36
 * @route '/panel'
 */
        panelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: panel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    panel.form = panelForm
/**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
export const reportes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportes.url(options),
    method: 'get',
})

reportes.definition = {
    methods: ["get","head"],
    url: '/reportes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
reportes.url = (options?: RouteQueryOptions) => {
    return reportes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
reportes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportes.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
reportes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reportes.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
    const reportesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reportes.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
        reportesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportes.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::reportes
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
        reportesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportes.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reportes.form = reportesForm
/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
export const crm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crm.url(options),
    method: 'get',
})

crm.definition = {
    methods: ["get","head"],
    url: '/crm',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
crm.url = (options?: RouteQueryOptions) => {
    return crm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
crm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
crm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: crm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
    const crmForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: crm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
        crmForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: crm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
        crmForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: crm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    crm.form = crmForm