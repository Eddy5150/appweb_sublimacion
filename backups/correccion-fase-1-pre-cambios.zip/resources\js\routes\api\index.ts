import dashboard from './dashboard'
import productos from './productos'
import clientes from './clientes'
import pedidos from './pedidos'
import caja from './caja'
const api = {
    dashboard: Object.assign(dashboard, dashboard),
productos: Object.assign(productos, productos),
clientes: Object.assign(clientes, clientes),
pedidos: Object.assign(pedidos, pedidos),
caja: Object.assign(caja, caja),
}

export default api