import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SaasController::store
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/saas/suscripciones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SaasController::store
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::store
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SaasController::store
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::store
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const subscriptions = {
    store: Object.assign(store, store),
}

export default subscriptions