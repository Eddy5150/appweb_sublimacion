import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CrmAutomationController::read
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
export const read = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

read.definition = {
    methods: ["post"],
    url: '/crm/alerts/{alert}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::read
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
read.url = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { alert: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { alert: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    alert: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        alert: typeof args.alert === 'object'
                ? args.alert.id
                : args.alert,
                }

    return read.definition.url
            .replace('{alert}', parsedArgs.alert.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::read
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
read.post = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::read
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
    const readForm = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: read.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::read
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
        readForm.post = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: read.url(args, options),
            method: 'post',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\CrmAutomationController::readAll
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

readAll.definition = {
    methods: ["post"],
    url: '/crm/alerts/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::readAll
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::readAll
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
readAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::readAll
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
    const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: readAll.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::readAll
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
        readAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: readAll.url(options),
            method: 'post',
        })
    
    readAll.form = readAllForm
const alerts = {
    read: Object.assign(read, read),
readAll: Object.assign(readAll, readAll),
}

export default alerts