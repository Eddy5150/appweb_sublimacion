import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
export const reglasIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reglasIndex.url(options),
    method: 'get',
})

reglasIndex.definition = {
    methods: ["get","head"],
    url: '/crm/automations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
reglasIndex.url = (options?: RouteQueryOptions) => {
    return reglasIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
reglasIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reglasIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
reglasIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reglasIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
    const reglasIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reglasIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
        reglasIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reglasIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::reglasIndex
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
        reglasIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reglasIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reglasIndex.form = reglasIndexForm
/**
* @see \App\Http\Controllers\CrmAutomationController::reglasStore
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
export const reglasStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reglasStore.url(options),
    method: 'post',
})

reglasStore.definition = {
    methods: ["post"],
    url: '/crm/automations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasStore
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
reglasStore.url = (options?: RouteQueryOptions) => {
    return reglasStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasStore
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
reglasStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reglasStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::reglasStore
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
    const reglasStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reglasStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::reglasStore
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
        reglasStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reglasStore.url(options),
            method: 'post',
        })
    
    reglasStore.form = reglasStoreForm
/**
* @see \App\Http\Controllers\CrmAutomationController::reglasUpdate
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
export const reglasUpdate = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reglasUpdate.url(args, options),
    method: 'put',
})

reglasUpdate.definition = {
    methods: ["put"],
    url: '/crm/automations/{regla}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasUpdate
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
reglasUpdate.url = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { regla: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { regla: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    regla: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        regla: typeof args.regla === 'object'
                ? args.regla.id
                : args.regla,
                }

    return reglasUpdate.definition.url
            .replace('{regla}', parsedArgs.regla.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasUpdate
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
reglasUpdate.put = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reglasUpdate.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::reglasUpdate
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
    const reglasUpdateForm = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reglasUpdate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::reglasUpdate
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
        reglasUpdateForm.put = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reglasUpdate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reglasUpdate.form = reglasUpdateForm
/**
* @see \App\Http\Controllers\CrmAutomationController::reglasDestroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
export const reglasDestroy = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: reglasDestroy.url(args, options),
    method: 'delete',
})

reglasDestroy.definition = {
    methods: ["delete"],
    url: '/crm/automations/{regla}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasDestroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
reglasDestroy.url = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { regla: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { regla: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    regla: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        regla: typeof args.regla === 'object'
                ? args.regla.id
                : args.regla,
                }

    return reglasDestroy.definition.url
            .replace('{regla}', parsedArgs.regla.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasDestroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
reglasDestroy.delete = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: reglasDestroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::reglasDestroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
    const reglasDestroyForm = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reglasDestroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::reglasDestroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
        reglasDestroyForm.delete = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reglasDestroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reglasDestroy.form = reglasDestroyForm
/**
* @see \App\Http\Controllers\CrmAutomationController::reglasToggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
export const reglasToggle = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reglasToggle.url(args, options),
    method: 'post',
})

reglasToggle.definition = {
    methods: ["post"],
    url: '/crm/automations/{regla}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasToggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
reglasToggle.url = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { regla: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { regla: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    regla: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        regla: typeof args.regla === 'object'
                ? args.regla.id
                : args.regla,
                }

    return reglasToggle.definition.url
            .replace('{regla}', parsedArgs.regla.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::reglasToggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
reglasToggle.post = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reglasToggle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::reglasToggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
    const reglasToggleForm = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reglasToggle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::reglasToggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
        reglasToggleForm.post = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reglasToggle.url(args, options),
            method: 'post',
        })
    
    reglasToggle.form = reglasToggleForm
/**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
export const alertsIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alertsIndex.url(options),
    method: 'get',
})

alertsIndex.definition = {
    methods: ["get","head"],
    url: '/crm/alerts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
alertsIndex.url = (options?: RouteQueryOptions) => {
    return alertsIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
alertsIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alertsIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
alertsIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: alertsIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
    const alertsIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: alertsIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
        alertsIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alertsIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::alertsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
        alertsIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alertsIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    alertsIndex.form = alertsIndexForm
/**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkRead
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
export const alertsMarkRead = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: alertsMarkRead.url(args, options),
    method: 'post',
})

alertsMarkRead.definition = {
    methods: ["post"],
    url: '/crm/alerts/{alert}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkRead
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
alertsMarkRead.url = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { alert: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { alert: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    alert: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        alert: typeof args.alert === 'object'
                ? args.alert.id
                : args.alert,
                }

    return alertsMarkRead.definition.url
            .replace('{alert}', parsedArgs.alert.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkRead
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
alertsMarkRead.post = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: alertsMarkRead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkRead
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
    const alertsMarkReadForm = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: alertsMarkRead.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkRead
 * @see app/Http/Controllers/CrmAutomationController.php:127
 * @route '/crm/alerts/{alert}/read'
 */
        alertsMarkReadForm.post = (args: { alert: string | number | { id: string | number } } | [alert: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: alertsMarkRead.url(args, options),
            method: 'post',
        })
    
    alertsMarkRead.form = alertsMarkReadForm
/**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkAllRead
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
export const alertsMarkAllRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: alertsMarkAllRead.url(options),
    method: 'post',
})

alertsMarkAllRead.definition = {
    methods: ["post"],
    url: '/crm/alerts/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkAllRead
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
alertsMarkAllRead.url = (options?: RouteQueryOptions) => {
    return alertsMarkAllRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkAllRead
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
alertsMarkAllRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: alertsMarkAllRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkAllRead
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
    const alertsMarkAllReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: alertsMarkAllRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::alertsMarkAllRead
 * @see app/Http/Controllers/CrmAutomationController.php:135
 * @route '/crm/alerts/read-all'
 */
        alertsMarkAllReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: alertsMarkAllRead.url(options),
            method: 'post',
        })
    
    alertsMarkAllRead.form = alertsMarkAllReadForm
/**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
export const eventsIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eventsIndex.url(options),
    method: 'get',
})

eventsIndex.definition = {
    methods: ["get","head"],
    url: '/crm/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
eventsIndex.url = (options?: RouteQueryOptions) => {
    return eventsIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
eventsIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eventsIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
eventsIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: eventsIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
    const eventsIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: eventsIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
        eventsIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: eventsIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::eventsIndex
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
        eventsIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: eventsIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    eventsIndex.form = eventsIndexForm
/**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
export const comunicacionesIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: comunicacionesIndex.url(options),
    method: 'get',
})

comunicacionesIndex.definition = {
    methods: ["get","head"],
    url: '/crm/comunicaciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
comunicacionesIndex.url = (options?: RouteQueryOptions) => {
    return comunicacionesIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
comunicacionesIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: comunicacionesIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
comunicacionesIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: comunicacionesIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
    const comunicacionesIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: comunicacionesIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
        comunicacionesIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: comunicacionesIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::comunicacionesIndex
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
        comunicacionesIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: comunicacionesIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    comunicacionesIndex.form = comunicacionesIndexForm
/**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
export const salesActions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: salesActions.url(options),
    method: 'get',
})

salesActions.definition = {
    methods: ["get","head"],
    url: '/crm/sales/actions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
salesActions.url = (options?: RouteQueryOptions) => {
    return salesActions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
salesActions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: salesActions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
salesActions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: salesActions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
    const salesActionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: salesActions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
        salesActionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: salesActions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::salesActions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
        salesActionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: salesActions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    salesActions.form = salesActionsForm
/**
* @see \App\Http\Controllers\CrmAutomationController::salesApprove
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
export const salesApprove = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: salesApprove.url(args, options),
    method: 'post',
})

salesApprove.definition = {
    methods: ["post"],
    url: '/crm/sales/actions/{action}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::salesApprove
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
salesApprove.url = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { action: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { action: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    action: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        action: typeof args.action === 'object'
                ? args.action.id
                : args.action,
                }

    return salesApprove.definition.url
            .replace('{action}', parsedArgs.action.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::salesApprove
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
salesApprove.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: salesApprove.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::salesApprove
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
    const salesApproveForm = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: salesApprove.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::salesApprove
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
        salesApproveForm.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: salesApprove.url(args, options),
            method: 'post',
        })
    
    salesApprove.form = salesApproveForm
/**
* @see \App\Http\Controllers\CrmAutomationController::salesExecute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
export const salesExecute = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: salesExecute.url(args, options),
    method: 'post',
})

salesExecute.definition = {
    methods: ["post"],
    url: '/crm/sales/actions/{action}/execute',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::salesExecute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
salesExecute.url = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { action: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { action: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    action: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        action: typeof args.action === 'object'
                ? args.action.id
                : args.action,
                }

    return salesExecute.definition.url
            .replace('{action}', parsedArgs.action.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::salesExecute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
salesExecute.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: salesExecute.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::salesExecute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
    const salesExecuteForm = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: salesExecute.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::salesExecute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
        salesExecuteForm.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: salesExecute.url(args, options),
            method: 'post',
        })
    
    salesExecute.form = salesExecuteForm
/**
* @see \App\Http\Controllers\CrmAutomationController::salesPipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
export const salesPipeline = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: salesPipeline.url(options),
    method: 'post',
})

salesPipeline.definition = {
    methods: ["post"],
    url: '/crm/sales/pipeline',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::salesPipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
salesPipeline.url = (options?: RouteQueryOptions) => {
    return salesPipeline.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::salesPipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
salesPipeline.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: salesPipeline.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::salesPipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
    const salesPipelineForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: salesPipeline.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::salesPipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
        salesPipelineForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: salesPipeline.url(options),
            method: 'post',
        })
    
    salesPipeline.form = salesPipelineForm
const CrmAutomationController = { reglasIndex, reglasStore, reglasUpdate, reglasDestroy, reglasToggle, alertsIndex, alertsMarkRead, alertsMarkAllRead, eventsIndex, comunicacionesIndex, salesActions, salesApprove, salesExecute, salesPipeline }

export default CrmAutomationController