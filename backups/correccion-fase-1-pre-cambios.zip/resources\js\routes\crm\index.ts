import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import automations582a2e from './automations'
import alerts080c72 from './alerts'
import automation from './automation'
import sales from './sales'
import ai335533 from './ai'
/**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
export const automations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: automations.url(options),
    method: 'get',
})

automations.definition = {
    methods: ["get","head"],
    url: '/crm/automations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
automations.url = (options?: RouteQueryOptions) => {
    return automations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
automations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: automations.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
automations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: automations.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
    const automationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: automations.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
        automationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: automations.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::automations
 * @see app/Http/Controllers/CrmAutomationController.php:23
 * @route '/crm/automations'
 */
        automationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: automations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    automations.form = automationsForm
/**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
export const alerts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alerts.url(options),
    method: 'get',
})

alerts.definition = {
    methods: ["get","head"],
    url: '/crm/alerts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
alerts.url = (options?: RouteQueryOptions) => {
    return alerts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
alerts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alerts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
alerts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: alerts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
    const alertsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: alerts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
        alertsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alerts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::alerts
 * @see app/Http/Controllers/CrmAutomationController.php:104
 * @route '/crm/alerts'
 */
        alertsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alerts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    alerts.form = alertsForm
/**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
export const events = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})

events.definition = {
    methods: ["get","head"],
    url: '/crm/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
events.url = (options?: RouteQueryOptions) => {
    return events.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
events.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
events.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: events.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
    const eventsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: events.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
        eventsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: events.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::events
 * @see app/Http/Controllers/CrmAutomationController.php:143
 * @route '/crm/events'
 */
        eventsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: events.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    events.form = eventsForm
/**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
export const comunicaciones = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: comunicaciones.url(options),
    method: 'get',
})

comunicaciones.definition = {
    methods: ["get","head"],
    url: '/crm/comunicaciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
comunicaciones.url = (options?: RouteQueryOptions) => {
    return comunicaciones.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
comunicaciones.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: comunicaciones.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
comunicaciones.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: comunicaciones.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
    const comunicacionesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: comunicaciones.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
        comunicacionesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: comunicaciones.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::comunicaciones
 * @see app/Http/Controllers/CrmAutomationController.php:169
 * @route '/crm/comunicaciones'
 */
        comunicacionesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: comunicaciones.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    comunicaciones.form = comunicacionesForm
/**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
export const ai = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ai.url(options),
    method: 'get',
})

ai.definition = {
    methods: ["get","head"],
    url: '/crm/ai',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
ai.url = (options?: RouteQueryOptions) => {
    return ai.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
ai.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ai.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
ai.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ai.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
    const aiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ai.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
        aiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ai.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAiController::ai
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
        aiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ai.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ai.form = aiForm
const crm = {
    automations: Object.assign(automations, automations582a2e),
alerts: Object.assign(alerts, alerts080c72),
events: Object.assign(events, events),
automation: Object.assign(automation, automation),
comunicaciones: Object.assign(comunicaciones, comunicaciones),
sales: Object.assign(sales, sales),
ai: Object.assign(ai, ai335533),
}

export default crm