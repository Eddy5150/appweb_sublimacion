import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/pedidos/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PedidoController::create
 * @see app/Http/Controllers/PedidoController.php:69
 * @route '/pedidos/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:80
 * @route '/pedidos'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pedidos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:80
 * @route '/pedidos'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:80
 * @route '/pedidos'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:80
 * @route '/pedidos'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:80
 * @route '/pedidos'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pedidos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PedidoController::index
 * @see app/Http/Controllers/PedidoController.php:21
 * @route '/pedidos'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
export const show = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pedidos/{pedido}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
show.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return show.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
show.get = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
show.head = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
    const showForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
        showForm.get = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PedidoController::show
 * @see app/Http/Controllers/PedidoController.php:131
 * @route '/pedidos/{pedido}'
 */
        showForm.head = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
export const edit = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/pedidos/{pedido}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
edit.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return edit.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
edit.get = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
edit.head = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
    const editForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
        editForm.get = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PedidoController::edit
 * @see app/Http/Controllers/PedidoController.php:140
 * @route '/pedidos/{pedido}/edit'
 */
        editForm.head = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
export const update = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/pedidos/{pedido}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
update.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return update.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
update.put = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
update.patch = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
    const updateForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
        updateForm.put = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\PedidoController::update
 * @see app/Http/Controllers/PedidoController.php:154
 * @route '/pedidos/{pedido}'
 */
        updateForm.patch = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\PedidoController::updateEstado
 * @see app/Http/Controllers/PedidoController.php:205
 * @route '/pedidos/{pedido}/estado'
 */
export const updateEstado = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateEstado.url(args, options),
    method: 'patch',
})

updateEstado.definition = {
    methods: ["patch"],
    url: '/pedidos/{pedido}/estado',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\PedidoController::updateEstado
 * @see app/Http/Controllers/PedidoController.php:205
 * @route '/pedidos/{pedido}/estado'
 */
updateEstado.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return updateEstado.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::updateEstado
 * @see app/Http/Controllers/PedidoController.php:205
 * @route '/pedidos/{pedido}/estado'
 */
updateEstado.patch = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateEstado.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\PedidoController::updateEstado
 * @see app/Http/Controllers/PedidoController.php:205
 * @route '/pedidos/{pedido}/estado'
 */
    const updateEstadoForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateEstado.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PedidoController::updateEstado
 * @see app/Http/Controllers/PedidoController.php:205
 * @route '/pedidos/{pedido}/estado'
 */
        updateEstadoForm.patch = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateEstado.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateEstado.form = updateEstadoForm
/**
* @see \App\Http\Controllers\PedidoController::destroy
 * @see app/Http/Controllers/PedidoController.php:247
 * @route '/pedidos/{pedido}'
 */
export const destroy = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pedidos/{pedido}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PedidoController::destroy
 * @see app/Http/Controllers/PedidoController.php:247
 * @route '/pedidos/{pedido}'
 */
destroy.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return destroy.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::destroy
 * @see app/Http/Controllers/PedidoController.php:247
 * @route '/pedidos/{pedido}'
 */
destroy.delete = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PedidoController::destroy
 * @see app/Http/Controllers/PedidoController.php:247
 * @route '/pedidos/{pedido}'
 */
    const destroyForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PedidoController::destroy
 * @see app/Http/Controllers/PedidoController.php:247
 * @route '/pedidos/{pedido}'
 */
        destroyForm.delete = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PedidoController = { create, store, index, show, edit, update, updateEstado, destroy }

export default PedidoController