import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
export const crm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crm.url(options),
    method: 'get',
})

crm.definition = {
    methods: ["get","head"],
    url: '/crm',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
crm.url = (options?: RouteQueryOptions) => {
    return crm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
crm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: crm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
crm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: crm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
    const crmForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: crm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
        crmForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: crm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::crm
 * @see app/Http/Controllers/ClienteController.php:164
 * @route '/crm'
 */
        crmForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: crm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    crm.form = crmForm
/**
* @see \App\Http\Controllers\ClienteController::clasificar
 * @see app/Http/Controllers/ClienteController.php:389
 * @route '/clientes/clasificar'
 */
export const clasificar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clasificar.url(options),
    method: 'post',
})

clasificar.definition = {
    methods: ["post"],
    url: '/clientes/clasificar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClienteController::clasificar
 * @see app/Http/Controllers/ClienteController.php:389
 * @route '/clientes/clasificar'
 */
clasificar.url = (options?: RouteQueryOptions) => {
    return clasificar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::clasificar
 * @see app/Http/Controllers/ClienteController.php:389
 * @route '/clientes/clasificar'
 */
clasificar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clasificar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClienteController::clasificar
 * @see app/Http/Controllers/ClienteController.php:389
 * @route '/clientes/clasificar'
 */
    const clasificarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clasificar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::clasificar
 * @see app/Http/Controllers/ClienteController.php:389
 * @route '/clientes/clasificar'
 */
        clasificarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clasificar.url(options),
            method: 'post',
        })
    
    clasificar.form = clasificarForm
/**
* @see \App\Http\Controllers\ClienteController::runAutomation
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
export const runAutomation = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: runAutomation.url(options),
    method: 'post',
})

runAutomation.definition = {
    methods: ["post"],
    url: '/crm/automation/run',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClienteController::runAutomation
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
runAutomation.url = (options?: RouteQueryOptions) => {
    return runAutomation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::runAutomation
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
runAutomation.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: runAutomation.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClienteController::runAutomation
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
    const runAutomationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: runAutomation.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::runAutomation
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
        runAutomationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: runAutomation.url(options),
            method: 'post',
        })
    
    runAutomation.form = runAutomationForm
/**
* @see \App\Http\Controllers\ClienteController::runAgent
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
export const runAgent = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: runAgent.url(options),
    method: 'post',
})

runAgent.definition = {
    methods: ["post"],
    url: '/crm/ai/agent/run',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClienteController::runAgent
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
runAgent.url = (options?: RouteQueryOptions) => {
    return runAgent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::runAgent
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
runAgent.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: runAgent.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClienteController::runAgent
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
    const runAgentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: runAgent.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::runAgent
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
        runAgentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: runAgent.url(options),
            method: 'post',
        })
    
    runAgent.form = runAgentForm
/**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
export const agentRecommendations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: agentRecommendations.url(options),
    method: 'get',
})

agentRecommendations.definition = {
    methods: ["get","head"],
    url: '/crm/ai/agent/recommendations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
agentRecommendations.url = (options?: RouteQueryOptions) => {
    return agentRecommendations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
agentRecommendations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: agentRecommendations.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
agentRecommendations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: agentRecommendations.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
    const agentRecommendationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: agentRecommendations.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
        agentRecommendationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: agentRecommendations.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::agentRecommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
        agentRecommendationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: agentRecommendations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    agentRecommendations.form = agentRecommendationsForm
/**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/clientes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::index
 * @see app/Http/Controllers/ClienteController.php:31
 * @route '/clientes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/clientes/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::create
 * @see app/Http/Controllers/ClienteController.php:64
 * @route '/clientes/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\ClienteController::store
 * @see app/Http/Controllers/ClienteController.php:69
 * @route '/clientes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clientes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClienteController::store
 * @see app/Http/Controllers/ClienteController.php:69
 * @route '/clientes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::store
 * @see app/Http/Controllers/ClienteController.php:69
 * @route '/clientes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClienteController::store
 * @see app/Http/Controllers/ClienteController.php:69
 * @route '/clientes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::store
 * @see app/Http/Controllers/ClienteController.php:69
 * @route '/clientes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
export const show = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/clientes/{cliente}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
show.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return show.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
show.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
show.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
    const showForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
        showForm.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::show
 * @see app/Http/Controllers/ClienteController.php:87
 * @route '/clientes/{cliente}'
 */
        showForm.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
export const edit = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/clientes/{cliente}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
edit.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return edit.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
edit.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
edit.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
    const editForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
        editForm.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::edit
 * @see app/Http/Controllers/ClienteController.php:133
 * @route '/clientes/{cliente}/edit'
 */
        editForm.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
export const update = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/clientes/{cliente}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
update.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return update.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
update.put = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
update.patch = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
    const updateForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
        updateForm.put = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\ClienteController::update
 * @see app/Http/Controllers/ClienteController.php:140
 * @route '/clientes/{cliente}'
 */
        updateForm.patch = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClienteController::destroy
 * @see app/Http/Controllers/ClienteController.php:156
 * @route '/clientes/{cliente}'
 */
export const destroy = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clientes/{cliente}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClienteController::destroy
 * @see app/Http/Controllers/ClienteController.php:156
 * @route '/clientes/{cliente}'
 */
destroy.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return destroy.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::destroy
 * @see app/Http/Controllers/ClienteController.php:156
 * @route '/clientes/{cliente}'
 */
destroy.delete = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClienteController::destroy
 * @see app/Http/Controllers/ClienteController.php:156
 * @route '/clientes/{cliente}'
 */
    const destroyForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::destroy
 * @see app/Http/Controllers/ClienteController.php:156
 * @route '/clientes/{cliente}'
 */
        destroyForm.delete = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClienteController = { crm, clasificar, runAutomation, runAgent, agentRecommendations, index, create, store, show, edit, update, destroy }

export default ClienteController