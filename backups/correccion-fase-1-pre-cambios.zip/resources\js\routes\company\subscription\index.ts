import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanyBillingController::upgrade
 * @see app/Http/Controllers/CompanyBillingController.php:54
 * @route '/configuracion/plan/upgrade'
 */
export const upgrade = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upgrade.url(options),
    method: 'post',
})

upgrade.definition = {
    methods: ["post"],
    url: '/configuracion/plan/upgrade',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanyBillingController::upgrade
 * @see app/Http/Controllers/CompanyBillingController.php:54
 * @route '/configuracion/plan/upgrade'
 */
upgrade.url = (options?: RouteQueryOptions) => {
    return upgrade.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanyBillingController::upgrade
 * @see app/Http/Controllers/CompanyBillingController.php:54
 * @route '/configuracion/plan/upgrade'
 */
upgrade.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upgrade.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanyBillingController::upgrade
 * @see app/Http/Controllers/CompanyBillingController.php:54
 * @route '/configuracion/plan/upgrade'
 */
    const upgradeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upgrade.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanyBillingController::upgrade
 * @see app/Http/Controllers/CompanyBillingController.php:54
 * @route '/configuracion/plan/upgrade'
 */
        upgradeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upgrade.url(options),
            method: 'post',
        })
    
    upgrade.form = upgradeForm
/**
* @see \App\Http\Controllers\CompanyBillingController::cancel
 * @see app/Http/Controllers/CompanyBillingController.php:75
 * @route '/configuracion/plan/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/configuracion/plan/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompanyBillingController::cancel
 * @see app/Http/Controllers/CompanyBillingController.php:75
 * @route '/configuracion/plan/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanyBillingController::cancel
 * @see app/Http/Controllers/CompanyBillingController.php:75
 * @route '/configuracion/plan/cancel'
 */
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompanyBillingController::cancel
 * @see app/Http/Controllers/CompanyBillingController.php:75
 * @route '/configuracion/plan/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanyBillingController::cancel
 * @see app/Http/Controllers/CompanyBillingController.php:75
 * @route '/configuracion/plan/cancel'
 */
        cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const subscription = {
    upgrade: Object.assign(upgrade, upgrade),
cancel: Object.assign(cancel, cancel),
}

export default subscription