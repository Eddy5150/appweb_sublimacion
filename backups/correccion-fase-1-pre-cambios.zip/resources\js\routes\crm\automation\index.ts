import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
export const run = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: run.url(options),
    method: 'post',
})

run.definition = {
    methods: ["post"],
    url: '/crm/automation/run',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
run.url = (options?: RouteQueryOptions) => {
    return run.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
run.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: run.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
    const runForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: run.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:397
 * @route '/crm/automation/run'
 */
        runForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: run.url(options),
            method: 'post',
        })
    
    run.form = runForm
const automation = {
    run: Object.assign(run, run),
}

export default automation