import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/pedidos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PedidoApiController::index
 * @see app/Http/Controllers/Api/PedidoApiController.php:19
 * @route '/api/v1/pedidos'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\PedidoApiController::store
 * @see app/Http/Controllers/Api/PedidoApiController.php:38
 * @route '/api/v1/pedidos'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/pedidos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PedidoApiController::store
 * @see app/Http/Controllers/Api/PedidoApiController.php:38
 * @route '/api/v1/pedidos'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PedidoApiController::store
 * @see app/Http/Controllers/Api/PedidoApiController.php:38
 * @route '/api/v1/pedidos'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PedidoApiController::store
 * @see app/Http/Controllers/Api/PedidoApiController.php:38
 * @route '/api/v1/pedidos'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PedidoApiController::store
 * @see app/Http/Controllers/Api/PedidoApiController.php:38
 * @route '/api/v1/pedidos'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
export const show = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/pedidos/{pedido}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
show.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return show.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
show.get = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
show.head = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
    const showForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
        showForm.get = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PedidoApiController::show
 * @see app/Http/Controllers/Api/PedidoApiController.php:31
 * @route '/api/v1/pedidos/{pedido}'
 */
        showForm.head = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
export const update = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/v1/pedidos/{pedido}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
update.url = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: args.pedido,
                }

    return update.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
update.put = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
update.patch = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
    const updateForm = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
        updateForm.put = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Api\PedidoApiController::update
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
        updateForm.patch = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\PedidoApiController::destroy
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
export const destroy = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/pedidos/{pedido}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\PedidoApiController::destroy
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
destroy.url = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: args.pedido,
                }

    return destroy.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PedidoApiController::destroy
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
destroy.delete = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\PedidoApiController::destroy
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
    const destroyForm = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PedidoApiController::destroy
 * @see app/Http/Controllers/Api/PedidoApiController.php:0
 * @route '/api/v1/pedidos/{pedido}'
 */
        destroyForm.delete = (args: { pedido: string | number } | [pedido: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\PedidoApiController::updateEstado
 * @see app/Http/Controllers/Api/PedidoApiController.php:79
 * @route '/api/v1/pedidos/{pedido}/estado'
 */
export const updateEstado = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateEstado.url(args, options),
    method: 'patch',
})

updateEstado.definition = {
    methods: ["patch"],
    url: '/api/v1/pedidos/{pedido}/estado',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\PedidoApiController::updateEstado
 * @see app/Http/Controllers/Api/PedidoApiController.php:79
 * @route '/api/v1/pedidos/{pedido}/estado'
 */
updateEstado.url = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return updateEstado.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PedidoApiController::updateEstado
 * @see app/Http/Controllers/Api/PedidoApiController.php:79
 * @route '/api/v1/pedidos/{pedido}/estado'
 */
updateEstado.patch = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateEstado.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\PedidoApiController::updateEstado
 * @see app/Http/Controllers/Api/PedidoApiController.php:79
 * @route '/api/v1/pedidos/{pedido}/estado'
 */
    const updateEstadoForm = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateEstado.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PedidoApiController::updateEstado
 * @see app/Http/Controllers/Api/PedidoApiController.php:79
 * @route '/api/v1/pedidos/{pedido}/estado'
 */
        updateEstadoForm.patch = (args: { pedido: string | number | { id: string | number } } | [pedido: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateEstado.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateEstado.form = updateEstadoForm
const PedidoApiController = { index, store, show, update, destroy, updateEstado }

export default PedidoApiController