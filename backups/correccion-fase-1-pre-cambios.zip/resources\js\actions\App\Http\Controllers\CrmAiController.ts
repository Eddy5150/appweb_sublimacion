import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/crm/ai',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAiController::index
 * @see app/Http/Controllers/CrmAiController.php:25
 * @route '/crm/ai'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
export const procesar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: procesar.url(options),
    method: 'post',
})

procesar.definition = {
    methods: ["post"],
    url: '/crm/ai/procesar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
procesar.url = (options?: RouteQueryOptions) => {
    return procesar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
procesar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: procesar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
    const procesarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: procesar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
        procesarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: procesar.url(options),
            method: 'post',
        })
    
    procesar.form = procesarForm
/**
* @see \App\Http\Controllers\CrmAiController::procesarCliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
export const procesarCliente = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: procesarCliente.url(args, options),
    method: 'post',
})

procesarCliente.definition = {
    methods: ["post"],
    url: '/crm/ai/cliente/{cliente}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAiController::procesarCliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
procesarCliente.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return procesarCliente.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::procesarCliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
procesarCliente.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: procesarCliente.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAiController::procesarCliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
    const procesarClienteForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: procesarCliente.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::procesarCliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
        procesarClienteForm.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: procesarCliente.url(args, options),
            method: 'post',
        })
    
    procesarCliente.form = procesarClienteForm
/**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
export const recomendaciones = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recomendaciones.url(args, options),
    method: 'post',
})

recomendaciones.definition = {
    methods: ["post"],
    url: '/crm/ai/cliente/{cliente}/recomendaciones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
recomendaciones.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return recomendaciones.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
recomendaciones.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recomendaciones.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
    const recomendacionesForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recomendaciones.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
        recomendacionesForm.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recomendaciones.url(args, options),
            method: 'post',
        })
    
    recomendaciones.form = recomendacionesForm
/**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
export const contactarHoy = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contactarHoy.url(options),
    method: 'get',
})

contactarHoy.definition = {
    methods: ["get","head"],
    url: '/crm/ai/contactar-hoy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
contactarHoy.url = (options?: RouteQueryOptions) => {
    return contactarHoy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
contactarHoy.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contactarHoy.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
contactarHoy.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contactarHoy.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
    const contactarHoyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contactarHoy.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
        contactarHoyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contactarHoy.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAiController::contactarHoy
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
        contactarHoyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contactarHoy.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contactarHoy.form = contactarHoyForm
/**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
export const insightCliente = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: insightCliente.url(args, options),
    method: 'get',
})

insightCliente.definition = {
    methods: ["get","head"],
    url: '/crm/ai/cliente/{cliente}/insight',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
insightCliente.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return insightCliente.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
insightCliente.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: insightCliente.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
insightCliente.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: insightCliente.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
    const insightClienteForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: insightCliente.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
        insightClienteForm.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: insightCliente.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAiController::insightCliente
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
        insightClienteForm.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: insightCliente.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    insightCliente.form = insightClienteForm
const CrmAiController = { index, procesar, procesarCliente, recomendaciones, contactarHoy, insightCliente }

export default CrmAiController