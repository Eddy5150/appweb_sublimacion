import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/saas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
export const companies = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companies.url(options),
    method: 'get',
})

companies.definition = {
    methods: ["get","head"],
    url: '/saas/empresas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
companies.url = (options?: RouteQueryOptions) => {
    return companies.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
companies.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companies.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
companies.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: companies.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
    const companiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: companies.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
        companiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companies.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
        companiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companies.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    companies.form = companiesForm
/**
* @see \App\Http\Controllers\SaasController::updateCompany
 * @see app/Http/Controllers/SaasController.php:101
 * @route '/saas/empresas/{company}'
 */
export const updateCompany = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCompany.url(args, options),
    method: 'patch',
})

updateCompany.definition = {
    methods: ["patch"],
    url: '/saas/empresas/{company}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\SaasController::updateCompany
 * @see app/Http/Controllers/SaasController.php:101
 * @route '/saas/empresas/{company}'
 */
updateCompany.url = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return updateCompany.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::updateCompany
 * @see app/Http/Controllers/SaasController.php:101
 * @route '/saas/empresas/{company}'
 */
updateCompany.patch = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCompany.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SaasController::updateCompany
 * @see app/Http/Controllers/SaasController.php:101
 * @route '/saas/empresas/{company}'
 */
    const updateCompanyForm = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCompany.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::updateCompany
 * @see app/Http/Controllers/SaasController.php:101
 * @route '/saas/empresas/{company}'
 */
        updateCompanyForm.patch = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCompany.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCompany.form = updateCompanyForm
/**
* @see \App\Http\Controllers\SaasController::toggleCompany
 * @see app/Http/Controllers/SaasController.php:120
 * @route '/saas/empresas/{company}/toggle'
 */
export const toggleCompany = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleCompany.url(args, options),
    method: 'post',
})

toggleCompany.definition = {
    methods: ["post"],
    url: '/saas/empresas/{company}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SaasController::toggleCompany
 * @see app/Http/Controllers/SaasController.php:120
 * @route '/saas/empresas/{company}/toggle'
 */
toggleCompany.url = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return toggleCompany.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::toggleCompany
 * @see app/Http/Controllers/SaasController.php:120
 * @route '/saas/empresas/{company}/toggle'
 */
toggleCompany.post = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleCompany.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SaasController::toggleCompany
 * @see app/Http/Controllers/SaasController.php:120
 * @route '/saas/empresas/{company}/toggle'
 */
    const toggleCompanyForm = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleCompany.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::toggleCompany
 * @see app/Http/Controllers/SaasController.php:120
 * @route '/saas/empresas/{company}/toggle'
 */
        toggleCompanyForm.post = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleCompany.url(args, options),
            method: 'post',
        })
    
    toggleCompany.form = toggleCompanyForm
/**
* @see \App\Http\Controllers\SaasController::deleteCompany
 * @see app/Http/Controllers/SaasController.php:137
 * @route '/saas/empresas/{company}'
 */
export const deleteCompany = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteCompany.url(args, options),
    method: 'delete',
})

deleteCompany.definition = {
    methods: ["delete"],
    url: '/saas/empresas/{company}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SaasController::deleteCompany
 * @see app/Http/Controllers/SaasController.php:137
 * @route '/saas/empresas/{company}'
 */
deleteCompany.url = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return deleteCompany.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::deleteCompany
 * @see app/Http/Controllers/SaasController.php:137
 * @route '/saas/empresas/{company}'
 */
deleteCompany.delete = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteCompany.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SaasController::deleteCompany
 * @see app/Http/Controllers/SaasController.php:137
 * @route '/saas/empresas/{company}'
 */
    const deleteCompanyForm = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteCompany.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::deleteCompany
 * @see app/Http/Controllers/SaasController.php:137
 * @route '/saas/empresas/{company}'
 */
        deleteCompanyForm.delete = (args: { company: string | number | { id: string | number } } | [company: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteCompany.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteCompany.form = deleteCompanyForm
/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
export const plans = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})

plans.definition = {
    methods: ["get","head"],
    url: '/saas/planes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
plans.url = (options?: RouteQueryOptions) => {
    return plans.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
plans.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
plans.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: plans.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
    const plansForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: plans.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
        plansForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: plans.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
        plansForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: plans.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    plans.form = plansForm
/**
* @see \App\Http\Controllers\SaasController::storePlan
 * @see app/Http/Controllers/SaasController.php:163
 * @route '/saas/planes'
 */
export const storePlan = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePlan.url(options),
    method: 'post',
})

storePlan.definition = {
    methods: ["post"],
    url: '/saas/planes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SaasController::storePlan
 * @see app/Http/Controllers/SaasController.php:163
 * @route '/saas/planes'
 */
storePlan.url = (options?: RouteQueryOptions) => {
    return storePlan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::storePlan
 * @see app/Http/Controllers/SaasController.php:163
 * @route '/saas/planes'
 */
storePlan.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePlan.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SaasController::storePlan
 * @see app/Http/Controllers/SaasController.php:163
 * @route '/saas/planes'
 */
    const storePlanForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePlan.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::storePlan
 * @see app/Http/Controllers/SaasController.php:163
 * @route '/saas/planes'
 */
        storePlanForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePlan.url(options),
            method: 'post',
        })
    
    storePlan.form = storePlanForm
/**
* @see \App\Http\Controllers\SaasController::updatePlan
 * @see app/Http/Controllers/SaasController.php:188
 * @route '/saas/planes/{plan}'
 */
export const updatePlan = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePlan.url(args, options),
    method: 'put',
})

updatePlan.definition = {
    methods: ["put"],
    url: '/saas/planes/{plan}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\SaasController::updatePlan
 * @see app/Http/Controllers/SaasController.php:188
 * @route '/saas/planes/{plan}'
 */
updatePlan.url = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return updatePlan.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::updatePlan
 * @see app/Http/Controllers/SaasController.php:188
 * @route '/saas/planes/{plan}'
 */
updatePlan.put = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePlan.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\SaasController::updatePlan
 * @see app/Http/Controllers/SaasController.php:188
 * @route '/saas/planes/{plan}'
 */
    const updatePlanForm = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePlan.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::updatePlan
 * @see app/Http/Controllers/SaasController.php:188
 * @route '/saas/planes/{plan}'
 */
        updatePlanForm.put = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePlan.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePlan.form = updatePlanForm
/**
* @see \App\Http\Controllers\SaasController::togglePlan
 * @see app/Http/Controllers/SaasController.php:213
 * @route '/saas/planes/{plan}/toggle'
 */
export const togglePlan = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: togglePlan.url(args, options),
    method: 'post',
})

togglePlan.definition = {
    methods: ["post"],
    url: '/saas/planes/{plan}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SaasController::togglePlan
 * @see app/Http/Controllers/SaasController.php:213
 * @route '/saas/planes/{plan}/toggle'
 */
togglePlan.url = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { plan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { plan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    plan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return togglePlan.definition.url
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::togglePlan
 * @see app/Http/Controllers/SaasController.php:213
 * @route '/saas/planes/{plan}/toggle'
 */
togglePlan.post = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: togglePlan.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SaasController::togglePlan
 * @see app/Http/Controllers/SaasController.php:213
 * @route '/saas/planes/{plan}/toggle'
 */
    const togglePlanForm = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: togglePlan.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::togglePlan
 * @see app/Http/Controllers/SaasController.php:213
 * @route '/saas/planes/{plan}/toggle'
 */
        togglePlanForm.post = (args: { plan: string | number | { id: string | number } } | [plan: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: togglePlan.url(args, options),
            method: 'post',
        })
    
    togglePlan.form = togglePlanForm
/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
export const subscriptions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subscriptions.url(options),
    method: 'get',
})

subscriptions.definition = {
    methods: ["get","head"],
    url: '/saas/suscripciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
subscriptions.url = (options?: RouteQueryOptions) => {
    return subscriptions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
subscriptions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subscriptions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
subscriptions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: subscriptions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
    const subscriptionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: subscriptions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
        subscriptionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subscriptions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
        subscriptionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subscriptions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    subscriptions.form = subscriptionsForm
/**
* @see \App\Http\Controllers\SaasController::storeSubscription
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
export const storeSubscription = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSubscription.url(options),
    method: 'post',
})

storeSubscription.definition = {
    methods: ["post"],
    url: '/saas/suscripciones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SaasController::storeSubscription
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
storeSubscription.url = (options?: RouteQueryOptions) => {
    return storeSubscription.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::storeSubscription
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
storeSubscription.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSubscription.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SaasController::storeSubscription
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
    const storeSubscriptionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSubscription.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SaasController::storeSubscription
 * @see app/Http/Controllers/SaasController.php:249
 * @route '/saas/suscripciones'
 */
        storeSubscriptionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSubscription.url(options),
            method: 'post',
        })
    
    storeSubscription.form = storeSubscriptionForm
const SaasController = { dashboard, companies, updateCompany, toggleCompany, deleteCompany, plans, storePlan, updatePlan, togglePlan, subscriptions, storeSubscription }

export default SaasController