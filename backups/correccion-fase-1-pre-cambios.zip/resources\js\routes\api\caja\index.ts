import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
export const actual = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: actual.url(options),
    method: 'get',
})

actual.definition = {
    methods: ["get","head"],
    url: '/api/v1/caja/actual',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
actual.url = (options?: RouteQueryOptions) => {
    return actual.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
actual.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: actual.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
actual.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: actual.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
    const actualForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: actual.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
        actualForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: actual.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CajaApiController::actual
 * @see app/Http/Controllers/Api/CajaApiController.php:13
 * @route '/api/v1/caja/actual'
 */
        actualForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: actual.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    actual.form = actualForm
/**
* @see \App\Http\Controllers\Api\CajaApiController::abrir
 * @see app/Http/Controllers/Api/CajaApiController.php:36
 * @route '/api/v1/caja/abrir'
 */
export const abrir = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: abrir.url(options),
    method: 'post',
})

abrir.definition = {
    methods: ["post"],
    url: '/api/v1/caja/abrir',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CajaApiController::abrir
 * @see app/Http/Controllers/Api/CajaApiController.php:36
 * @route '/api/v1/caja/abrir'
 */
abrir.url = (options?: RouteQueryOptions) => {
    return abrir.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CajaApiController::abrir
 * @see app/Http/Controllers/Api/CajaApiController.php:36
 * @route '/api/v1/caja/abrir'
 */
abrir.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: abrir.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CajaApiController::abrir
 * @see app/Http/Controllers/Api/CajaApiController.php:36
 * @route '/api/v1/caja/abrir'
 */
    const abrirForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: abrir.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CajaApiController::abrir
 * @see app/Http/Controllers/Api/CajaApiController.php:36
 * @route '/api/v1/caja/abrir'
 */
        abrirForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: abrir.url(options),
            method: 'post',
        })
    
    abrir.form = abrirForm
/**
* @see \App\Http\Controllers\Api\CajaApiController::cerrar
 * @see app/Http/Controllers/Api/CajaApiController.php:61
 * @route '/api/v1/caja/cerrar'
 */
export const cerrar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cerrar.url(options),
    method: 'post',
})

cerrar.definition = {
    methods: ["post"],
    url: '/api/v1/caja/cerrar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CajaApiController::cerrar
 * @see app/Http/Controllers/Api/CajaApiController.php:61
 * @route '/api/v1/caja/cerrar'
 */
cerrar.url = (options?: RouteQueryOptions) => {
    return cerrar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CajaApiController::cerrar
 * @see app/Http/Controllers/Api/CajaApiController.php:61
 * @route '/api/v1/caja/cerrar'
 */
cerrar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cerrar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CajaApiController::cerrar
 * @see app/Http/Controllers/Api/CajaApiController.php:61
 * @route '/api/v1/caja/cerrar'
 */
    const cerrarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cerrar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CajaApiController::cerrar
 * @see app/Http/Controllers/Api/CajaApiController.php:61
 * @route '/api/v1/caja/cerrar'
 */
        cerrarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cerrar.url(options),
            method: 'post',
        })
    
    cerrar.form = cerrarForm
/**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
export const movimientos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movimientos.url(options),
    method: 'get',
})

movimientos.definition = {
    methods: ["get","head"],
    url: '/api/v1/caja/movimientos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
movimientos.url = (options?: RouteQueryOptions) => {
    return movimientos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
movimientos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movimientos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
movimientos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movimientos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
    const movimientosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: movimientos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
        movimientosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movimientos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CajaApiController::movimientos
 * @see app/Http/Controllers/Api/CajaApiController.php:82
 * @route '/api/v1/caja/movimientos'
 */
        movimientosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movimientos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    movimientos.form = movimientosForm
const caja = {
    actual: Object.assign(actual, actual),
abrir: Object.assign(abrir, abrir),
cerrar: Object.assign(cerrar, cerrar),
movimientos: Object.assign(movimientos, movimientos),
}

export default caja