import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
export const run = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: run.url(options),
    method: 'post',
})

run.definition = {
    methods: ["post"],
    url: '/crm/ai/agent/run',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
run.url = (options?: RouteQueryOptions) => {
    return run.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
run.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: run.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
    const runForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: run.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClienteController::run
 * @see app/Http/Controllers/ClienteController.php:407
 * @route '/crm/ai/agent/run'
 */
        runForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: run.url(options),
            method: 'post',
        })
    
    run.form = runForm
/**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
export const recommendations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recommendations.url(options),
    method: 'get',
})

recommendations.definition = {
    methods: ["get","head"],
    url: '/crm/ai/agent/recommendations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
recommendations.url = (options?: RouteQueryOptions) => {
    return recommendations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
recommendations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recommendations.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
recommendations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recommendations.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
    const recommendationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: recommendations.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
        recommendationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: recommendations.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClienteController::recommendations
 * @see app/Http/Controllers/ClienteController.php:415
 * @route '/crm/ai/agent/recommendations'
 */
        recommendationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: recommendations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    recommendations.form = recommendationsForm
const agent = {
    run: Object.assign(run, run),
recommendations: Object.assign(recommendations, recommendations),
}

export default agent