import Api from './Api'
import CatalogoController from './CatalogoController'
import PedidoController from './PedidoController'
import ProductoController from './ProductoController'
import ReporteController from './ReporteController'
import RoleController from './RoleController'
import ClienteController from './ClienteController'
import CrmAutomationController from './CrmAutomationController'
import CrmAiController from './CrmAiController'
import UsuarioController from './UsuarioController'
import ProveedorController from './ProveedorController'
import CompraController from './CompraController'
import CompanySettingsController from './CompanySettingsController'
import CompanyBillingController from './CompanyBillingController'
import CajaController from './CajaController'
import ActivityLogController from './ActivityLogController'
import SaasController from './SaasController'
import Settings from './Settings'
const Controllers = {
    Api: Object.assign(Api, Api),
CatalogoController: Object.assign(CatalogoController, CatalogoController),
PedidoController: Object.assign(PedidoController, PedidoController),
ProductoController: Object.assign(ProductoController, ProductoController),
ReporteController: Object.assign(ReporteController, ReporteController),
RoleController: Object.assign(RoleController, RoleController),
ClienteController: Object.assign(ClienteController, ClienteController),
CrmAutomationController: Object.assign(CrmAutomationController, CrmAutomationController),
CrmAiController: Object.assign(CrmAiController, CrmAiController),
UsuarioController: Object.assign(UsuarioController, UsuarioController),
ProveedorController: Object.assign(ProveedorController, ProveedorController),
CompraController: Object.assign(CompraController, CompraController),
CompanySettingsController: Object.assign(CompanySettingsController, CompanySettingsController),
CompanyBillingController: Object.assign(CompanyBillingController, CompanyBillingController),
CajaController: Object.assign(CajaController, CajaController),
ActivityLogController: Object.assign(ActivityLogController, ActivityLogController),
SaasController: Object.assign(SaasController, SaasController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers