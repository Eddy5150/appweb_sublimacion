import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/catalogo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CatalogoController::index
 * @see app/Http/Controllers/CatalogoController.php:34
 * @route '/catalogo'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CatalogoController::store
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/carrito/confirmar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogoController::store
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogoController::store
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogoController::store
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogoController::store
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const CatalogoController = { index, store }

export default CatalogoController