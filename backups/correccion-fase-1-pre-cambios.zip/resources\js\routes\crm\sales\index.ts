import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
export const actions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: actions.url(options),
    method: 'get',
})

actions.definition = {
    methods: ["get","head"],
    url: '/crm/sales/actions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
actions.url = (options?: RouteQueryOptions) => {
    return actions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
actions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: actions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
actions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: actions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
    const actionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: actions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
        actionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: actions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAutomationController::actions
 * @see app/Http/Controllers/CrmAutomationController.php:192
 * @route '/crm/sales/actions'
 */
        actionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: actions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    actions.form = actionsForm
/**
* @see \App\Http\Controllers\CrmAutomationController::approve
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
export const approve = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/crm/sales/actions/{action}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::approve
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
approve.url = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { action: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { action: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    action: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        action: typeof args.action === 'object'
                ? args.action.id
                : args.action,
                }

    return approve.definition.url
            .replace('{action}', parsedArgs.action.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::approve
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
approve.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::approve
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
    const approveForm = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::approve
 * @see app/Http/Controllers/CrmAutomationController.php:201
 * @route '/crm/sales/actions/{action}/approve'
 */
        approveForm.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\CrmAutomationController::execute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
export const execute = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(args, options),
    method: 'post',
})

execute.definition = {
    methods: ["post"],
    url: '/crm/sales/actions/{action}/execute',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::execute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
execute.url = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { action: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { action: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    action: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        action: typeof args.action === 'object'
                ? args.action.id
                : args.action,
                }

    return execute.definition.url
            .replace('{action}', parsedArgs.action.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::execute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
execute.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::execute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
    const executeForm = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: execute.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::execute
 * @see app/Http/Controllers/CrmAutomationController.php:209
 * @route '/crm/sales/actions/{action}/execute'
 */
        executeForm.post = (args: { action: string | number | { id: string | number } } | [action: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: execute.url(args, options),
            method: 'post',
        })
    
    execute.form = executeForm
/**
* @see \App\Http\Controllers\CrmAutomationController::pipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
export const pipeline = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pipeline.url(options),
    method: 'post',
})

pipeline.definition = {
    methods: ["post"],
    url: '/crm/sales/pipeline',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::pipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
pipeline.url = (options?: RouteQueryOptions) => {
    return pipeline.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::pipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
pipeline.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pipeline.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::pipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
    const pipelineForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pipeline.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::pipeline
 * @see app/Http/Controllers/CrmAutomationController.php:217
 * @route '/crm/sales/pipeline'
 */
        pipelineForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pipeline.url(options),
            method: 'post',
        })
    
    pipeline.form = pipelineForm
const sales = {
    actions: Object.assign(actions, actions),
approve: Object.assign(approve, approve),
execute: Object.assign(execute, execute),
pipeline: Object.assign(pipeline, pipeline),
}

export default sales