import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reportes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::index
 * @see app/Http/Controllers/ReporteController.php:16
 * @route '/reportes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
export const ventasPorFecha = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasPorFecha.url(options),
    method: 'get',
})

ventasPorFecha.definition = {
    methods: ["get","head"],
    url: '/reportes/ventas-fecha',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
ventasPorFecha.url = (options?: RouteQueryOptions) => {
    return ventasPorFecha.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
ventasPorFecha.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasPorFecha.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
ventasPorFecha.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ventasPorFecha.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
    const ventasPorFechaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ventasPorFecha.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
        ventasPorFechaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasPorFecha.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::ventasPorFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
        ventasPorFechaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasPorFecha.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ventasPorFecha.form = ventasPorFechaForm
/**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
export const productosMasVendidos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productosMasVendidos.url(options),
    method: 'get',
})

productosMasVendidos.definition = {
    methods: ["get","head"],
    url: '/reportes/productos-top',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
productosMasVendidos.url = (options?: RouteQueryOptions) => {
    return productosMasVendidos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
productosMasVendidos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productosMasVendidos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
productosMasVendidos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: productosMasVendidos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
    const productosMasVendidosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: productosMasVendidos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
        productosMasVendidosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: productosMasVendidos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::productosMasVendidos
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
        productosMasVendidosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: productosMasVendidos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    productosMasVendidos.form = productosMasVendidosForm
/**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
export const pedidosPorEstado = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pedidosPorEstado.url(options),
    method: 'get',
})

pedidosPorEstado.definition = {
    methods: ["get","head"],
    url: '/reportes/estados',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
pedidosPorEstado.url = (options?: RouteQueryOptions) => {
    return pedidosPorEstado.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
pedidosPorEstado.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pedidosPorEstado.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
pedidosPorEstado.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pedidosPorEstado.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
    const pedidosPorEstadoForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pedidosPorEstado.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
        pedidosPorEstadoForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pedidosPorEstado.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::pedidosPorEstado
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
        pedidosPorEstadoForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pedidosPorEstado.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pedidosPorEstado.form = pedidosPorEstadoForm
/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
export const exportarPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarPdf.url(options),
    method: 'get',
})

exportarPdf.definition = {
    methods: ["get","head"],
    url: '/reportes/exportar-pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
exportarPdf.url = (options?: RouteQueryOptions) => {
    return exportarPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
exportarPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
exportarPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportarPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
    const exportarPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportarPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
        exportarPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
        exportarPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportarPdf.form = exportarPdfForm
/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
export const exportarExcel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarExcel.url(options),
    method: 'get',
})

exportarExcel.definition = {
    methods: ["get","head"],
    url: '/reportes/exportar-excel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
exportarExcel.url = (options?: RouteQueryOptions) => {
    return exportarExcel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
exportarExcel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarExcel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
exportarExcel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportarExcel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
    const exportarExcelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportarExcel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
        exportarExcelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarExcel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
        exportarExcelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarExcel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportarExcel.form = exportarExcelForm
const ReporteController = { index, ventasPorFecha, productosMasVendidos, pedidosPorEstado, exportarPdf, exportarExcel }

export default ReporteController