import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import settings69f00b from './settings'
import subscription from './subscription'
/**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
export const settings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/configuracion/empresa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
settings.url = (options?: RouteQueryOptions) => {
    return settings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
settings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
settings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
    const settingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: settings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
        settingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettingsController::settings
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
        settingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    settings.form = settingsForm
/**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
export const billing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: billing.url(options),
    method: 'get',
})

billing.definition = {
    methods: ["get","head"],
    url: '/configuracion/facturacion',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
billing.url = (options?: RouteQueryOptions) => {
    return billing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
billing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: billing.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
billing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: billing.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
    const billingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: billing.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
        billingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: billing.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanyBillingController::billing
 * @see app/Http/Controllers/CompanyBillingController.php:23
 * @route '/configuracion/facturacion'
 */
        billingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: billing.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    billing.form = billingForm
const company = {
    settings: Object.assign(settings, settings69f00b),
billing: Object.assign(billing, billing),
subscription: Object.assign(subscription, subscription),
}

export default company