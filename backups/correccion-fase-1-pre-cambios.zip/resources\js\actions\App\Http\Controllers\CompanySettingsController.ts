import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/configuracion/empresa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompanySettingsController::edit
 * @see app/Http/Controllers/CompanySettingsController.php:13
 * @route '/configuracion/empresa'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/configuracion/empresa',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const CompanySettingsController = { edit, update }

export default CompanySettingsController