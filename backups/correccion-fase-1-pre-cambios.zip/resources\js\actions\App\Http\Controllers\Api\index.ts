import DashboardApiController from './DashboardApiController'
import ProductoApiController from './ProductoApiController'
import ClienteApiController from './ClienteApiController'
import PedidoApiController from './PedidoApiController'
import CajaApiController from './CajaApiController'
const Api = {
    DashboardApiController: Object.assign(DashboardApiController, DashboardApiController),
ProductoApiController: Object.assign(ProductoApiController, ProductoApiController),
ClienteApiController: Object.assign(ClienteApiController, ClienteApiController),
PedidoApiController: Object.assign(PedidoApiController, PedidoApiController),
CajaApiController: Object.assign(CajaApiController, CajaApiController),
}

export default Api