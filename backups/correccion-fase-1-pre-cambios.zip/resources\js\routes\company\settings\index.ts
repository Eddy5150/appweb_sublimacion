import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/configuracion/empresa',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompanySettingsController::update
 * @see app/Http/Controllers/CompanySettingsController.php:29
 * @route '/configuracion/empresa'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const settings = {
    update: Object.assign(update, update),
}

export default settings