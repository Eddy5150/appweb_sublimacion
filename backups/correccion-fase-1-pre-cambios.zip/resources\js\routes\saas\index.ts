import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import companies63d7b1 from './companies'
import plansDaef78 from './plans'
import subscriptionsF46e2f from './subscriptions'
/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/saas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::dashboard
 * @see app/Http/Controllers/SaasController.php:19
 * @route '/saas'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
export const companies = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companies.url(options),
    method: 'get',
})

companies.definition = {
    methods: ["get","head"],
    url: '/saas/empresas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
companies.url = (options?: RouteQueryOptions) => {
    return companies.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
companies.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companies.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
companies.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: companies.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
    const companiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: companies.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
        companiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companies.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::companies
 * @see app/Http/Controllers/SaasController.php:74
 * @route '/saas/empresas'
 */
        companiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companies.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    companies.form = companiesForm
/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
export const plans = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})

plans.definition = {
    methods: ["get","head"],
    url: '/saas/planes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
plans.url = (options?: RouteQueryOptions) => {
    return plans.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
plans.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
plans.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: plans.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
    const plansForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: plans.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
        plansForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: plans.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::plans
 * @see app/Http/Controllers/SaasController.php:154
 * @route '/saas/planes'
 */
        plansForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: plans.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    plans.form = plansForm
/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
export const subscriptions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subscriptions.url(options),
    method: 'get',
})

subscriptions.definition = {
    methods: ["get","head"],
    url: '/saas/suscripciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
subscriptions.url = (options?: RouteQueryOptions) => {
    return subscriptions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
subscriptions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subscriptions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
subscriptions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: subscriptions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
    const subscriptionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: subscriptions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
        subscriptionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subscriptions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SaasController::subscriptions
 * @see app/Http/Controllers/SaasController.php:221
 * @route '/saas/suscripciones'
 */
        subscriptionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subscriptions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    subscriptions.form = subscriptionsForm
const saas = {
    dashboard: Object.assign(dashboard, dashboard),
companies: Object.assign(companies, companies63d7b1),
plans: Object.assign(plans, plansDaef78),
subscriptions: Object.assign(subscriptions, subscriptionsF46e2f),
}

export default saas