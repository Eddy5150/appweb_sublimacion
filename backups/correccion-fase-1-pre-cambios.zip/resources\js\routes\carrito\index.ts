import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogoController::confirmar
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
export const confirmar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmar.url(options),
    method: 'post',
})

confirmar.definition = {
    methods: ["post"],
    url: '/carrito/confirmar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogoController::confirmar
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
confirmar.url = (options?: RouteQueryOptions) => {
    return confirmar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogoController::confirmar
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
confirmar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogoController::confirmar
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
    const confirmarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: confirmar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogoController::confirmar
 * @see app/Http/Controllers/CatalogoController.php:96
 * @route '/carrito/confirmar'
 */
        confirmarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: confirmar.url(options),
            method: 'post',
        })
    
    confirmar.form = confirmarForm
const carrito = {
    confirmar: Object.assign(confirmar, confirmar),
}

export default carrito