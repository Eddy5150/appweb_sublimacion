import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CrmAutomationController::store
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/crm/automations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::store
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::store
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::store
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::store
 * @see app/Http/Controllers/CrmAutomationController.php:46
 * @route '/crm/automations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CrmAutomationController::update
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
export const update = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/crm/automations/{regla}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::update
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
update.url = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { regla: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { regla: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    regla: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        regla: typeof args.regla === 'object'
                ? args.regla.id
                : args.regla,
                }

    return update.definition.url
            .replace('{regla}', parsedArgs.regla.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::update
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
update.put = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::update
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
    const updateForm = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::update
 * @see app/Http/Controllers/CrmAutomationController.php:67
 * @route '/crm/automations/{regla}'
 */
        updateForm.put = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CrmAutomationController::destroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
export const destroy = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/crm/automations/{regla}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::destroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
destroy.url = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { regla: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { regla: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    regla: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        regla: typeof args.regla === 'object'
                ? args.regla.id
                : args.regla,
                }

    return destroy.definition.url
            .replace('{regla}', parsedArgs.regla.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::destroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
destroy.delete = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::destroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
    const destroyForm = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::destroy
 * @see app/Http/Controllers/CrmAutomationController.php:88
 * @route '/crm/automations/{regla}'
 */
        destroyForm.delete = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\CrmAutomationController::toggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
export const toggle = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/crm/automations/{regla}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAutomationController::toggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
toggle.url = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { regla: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { regla: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    regla: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        regla: typeof args.regla === 'object'
                ? args.regla.id
                : args.regla,
                }

    return toggle.definition.url
            .replace('{regla}', parsedArgs.regla.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAutomationController::toggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
toggle.post = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAutomationController::toggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
    const toggleForm = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAutomationController::toggle
 * @see app/Http/Controllers/CrmAutomationController.php:96
 * @route '/crm/automations/{regla}/toggle'
 */
        toggleForm.post = (args: { regla: string | number | { id: string | number } } | [regla: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, options),
            method: 'post',
        })
    
    toggle.form = toggleForm
const automations = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
toggle: Object.assign(toggle, toggle),
}

export default automations