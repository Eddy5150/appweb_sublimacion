import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/proveedores',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProveedorController::index
 * @see app/Http/Controllers/ProveedorController.php:13
 * @route '/proveedores'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/proveedores/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProveedorController::create
 * @see app/Http/Controllers/ProveedorController.php:35
 * @route '/proveedores/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\ProveedorController::store
 * @see app/Http/Controllers/ProveedorController.php:40
 * @route '/proveedores'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/proveedores',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProveedorController::store
 * @see app/Http/Controllers/ProveedorController.php:40
 * @route '/proveedores'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::store
 * @see app/Http/Controllers/ProveedorController.php:40
 * @route '/proveedores'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProveedorController::store
 * @see app/Http/Controllers/ProveedorController.php:40
 * @route '/proveedores'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::store
 * @see app/Http/Controllers/ProveedorController.php:40
 * @route '/proveedores'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
export const show = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/proveedores/{proveedor}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
show.url = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { proveedor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { proveedor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    proveedor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        proveedor: typeof args.proveedor === 'object'
                ? args.proveedor.id
                : args.proveedor,
                }

    return show.definition.url
            .replace('{proveedor}', parsedArgs.proveedor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
show.get = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
show.head = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
    const showForm = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
        showForm.get = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProveedorController::show
 * @see app/Http/Controllers/ProveedorController.php:59
 * @route '/proveedores/{proveedor}'
 */
        showForm.head = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
export const edit = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/proveedores/{proveedor}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
edit.url = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { proveedor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { proveedor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    proveedor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        proveedor: typeof args.proveedor === 'object'
                ? args.proveedor.id
                : args.proveedor,
                }

    return edit.definition.url
            .replace('{proveedor}', parsedArgs.proveedor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
edit.get = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
edit.head = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
    const editForm = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
        editForm.get = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProveedorController::edit
 * @see app/Http/Controllers/ProveedorController.php:71
 * @route '/proveedores/{proveedor}/edit'
 */
        editForm.head = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
export const update = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/proveedores/{proveedor}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
update.url = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { proveedor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { proveedor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    proveedor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        proveedor: typeof args.proveedor === 'object'
                ? args.proveedor.id
                : args.proveedor,
                }

    return update.definition.url
            .replace('{proveedor}', parsedArgs.proveedor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
update.put = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
update.patch = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
    const updateForm = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
        updateForm.put = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\ProveedorController::update
 * @see app/Http/Controllers/ProveedorController.php:78
 * @route '/proveedores/{proveedor}'
 */
        updateForm.patch = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProveedorController::toggle
 * @see app/Http/Controllers/ProveedorController.php:97
 * @route '/proveedores/{proveedor}/toggle'
 */
export const toggle = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/proveedores/{proveedor}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProveedorController::toggle
 * @see app/Http/Controllers/ProveedorController.php:97
 * @route '/proveedores/{proveedor}/toggle'
 */
toggle.url = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { proveedor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { proveedor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    proveedor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        proveedor: typeof args.proveedor === 'object'
                ? args.proveedor.id
                : args.proveedor,
                }

    return toggle.definition.url
            .replace('{proveedor}', parsedArgs.proveedor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::toggle
 * @see app/Http/Controllers/ProveedorController.php:97
 * @route '/proveedores/{proveedor}/toggle'
 */
toggle.post = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProveedorController::toggle
 * @see app/Http/Controllers/ProveedorController.php:97
 * @route '/proveedores/{proveedor}/toggle'
 */
    const toggleForm = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::toggle
 * @see app/Http/Controllers/ProveedorController.php:97
 * @route '/proveedores/{proveedor}/toggle'
 */
        toggleForm.post = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, options),
            method: 'post',
        })
    
    toggle.form = toggleForm
/**
* @see \App\Http\Controllers\ProveedorController::destroy
 * @see app/Http/Controllers/ProveedorController.php:105
 * @route '/proveedores/{proveedor}'
 */
export const destroy = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/proveedores/{proveedor}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProveedorController::destroy
 * @see app/Http/Controllers/ProveedorController.php:105
 * @route '/proveedores/{proveedor}'
 */
destroy.url = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { proveedor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { proveedor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    proveedor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        proveedor: typeof args.proveedor === 'object'
                ? args.proveedor.id
                : args.proveedor,
                }

    return destroy.definition.url
            .replace('{proveedor}', parsedArgs.proveedor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProveedorController::destroy
 * @see app/Http/Controllers/ProveedorController.php:105
 * @route '/proveedores/{proveedor}'
 */
destroy.delete = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProveedorController::destroy
 * @see app/Http/Controllers/ProveedorController.php:105
 * @route '/proveedores/{proveedor}'
 */
    const destroyForm = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProveedorController::destroy
 * @see app/Http/Controllers/ProveedorController.php:105
 * @route '/proveedores/{proveedor}'
 */
        destroyForm.delete = (args: { proveedor: string | number | { id: string | number } } | [proveedor: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const proveedores = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
toggle: Object.assign(toggle, toggle),
destroy: Object.assign(destroy, destroy),
}

export default proveedores