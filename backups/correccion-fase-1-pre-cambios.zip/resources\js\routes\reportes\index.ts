import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
export const ventasFecha = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasFecha.url(options),
    method: 'get',
})

ventasFecha.definition = {
    methods: ["get","head"],
    url: '/reportes/ventas-fecha',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
ventasFecha.url = (options?: RouteQueryOptions) => {
    return ventasFecha.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
ventasFecha.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasFecha.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
ventasFecha.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ventasFecha.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
    const ventasFechaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ventasFecha.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
        ventasFechaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasFecha.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::ventasFecha
 * @see app/Http/Controllers/ReporteController.php:53
 * @route '/reportes/ventas-fecha'
 */
        ventasFechaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasFecha.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ventasFecha.form = ventasFechaForm
/**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
export const productosTop = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productosTop.url(options),
    method: 'get',
})

productosTop.definition = {
    methods: ["get","head"],
    url: '/reportes/productos-top',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
productosTop.url = (options?: RouteQueryOptions) => {
    return productosTop.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
productosTop.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: productosTop.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
productosTop.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: productosTop.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
    const productosTopForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: productosTop.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
        productosTopForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: productosTop.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::productosTop
 * @see app/Http/Controllers/ReporteController.php:73
 * @route '/reportes/productos-top'
 */
        productosTopForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: productosTop.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    productosTop.form = productosTopForm
/**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
export const estados = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: estados.url(options),
    method: 'get',
})

estados.definition = {
    methods: ["get","head"],
    url: '/reportes/estados',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
estados.url = (options?: RouteQueryOptions) => {
    return estados.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
estados.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: estados.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
estados.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: estados.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
    const estadosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: estados.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
        estadosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: estados.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::estados
 * @see app/Http/Controllers/ReporteController.php:78
 * @route '/reportes/estados'
 */
        estadosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: estados.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    estados.form = estadosForm
/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
export const exportarPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarPdf.url(options),
    method: 'get',
})

exportarPdf.definition = {
    methods: ["get","head"],
    url: '/reportes/exportar-pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
exportarPdf.url = (options?: RouteQueryOptions) => {
    return exportarPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
exportarPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
exportarPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportarPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
    const exportarPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportarPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
        exportarPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::exportarPdf
 * @see app/Http/Controllers/ReporteController.php:89
 * @route '/reportes/exportar-pdf'
 */
        exportarPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportarPdf.form = exportarPdfForm
/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
export const exportarExcel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarExcel.url(options),
    method: 'get',
})

exportarExcel.definition = {
    methods: ["get","head"],
    url: '/reportes/exportar-excel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
exportarExcel.url = (options?: RouteQueryOptions) => {
    return exportarExcel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
exportarExcel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportarExcel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
exportarExcel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportarExcel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
    const exportarExcelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportarExcel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
        exportarExcelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarExcel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReporteController::exportarExcel
 * @see app/Http/Controllers/ReporteController.php:116
 * @route '/reportes/exportar-excel'
 */
        exportarExcelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportarExcel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportarExcel.form = exportarExcelForm
const reportes = {
    ventasFecha: Object.assign(ventasFecha, ventasFecha),
productosTop: Object.assign(productosTop, productosTop),
estados: Object.assign(estados, estados),
exportarPdf: Object.assign(exportarPdf, exportarPdf),
exportarExcel: Object.assign(exportarExcel, exportarExcel),
}

export default reportes