import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import agent from './agent'
/**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
export const procesar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: procesar.url(options),
    method: 'post',
})

procesar.definition = {
    methods: ["post"],
    url: '/crm/ai/procesar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
procesar.url = (options?: RouteQueryOptions) => {
    return procesar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
procesar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: procesar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
    const procesarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: procesar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::procesar
 * @see app/Http/Controllers/CrmAiController.php:66
 * @route '/crm/ai/procesar'
 */
        procesarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: procesar.url(options),
            method: 'post',
        })
    
    procesar.form = procesarForm
/**
* @see \App\Http\Controllers\CrmAiController::cliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
export const cliente = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cliente.url(args, options),
    method: 'post',
})

cliente.definition = {
    methods: ["post"],
    url: '/crm/ai/cliente/{cliente}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAiController::cliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
cliente.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return cliente.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::cliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
cliente.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cliente.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAiController::cliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
    const clienteForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cliente.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::cliente
 * @see app/Http/Controllers/CrmAiController.php:74
 * @route '/crm/ai/cliente/{cliente}'
 */
        clienteForm.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cliente.url(args, options),
            method: 'post',
        })
    
    cliente.form = clienteForm
/**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
export const recomendaciones = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recomendaciones.url(args, options),
    method: 'post',
})

recomendaciones.definition = {
    methods: ["post"],
    url: '/crm/ai/cliente/{cliente}/recomendaciones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
recomendaciones.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return recomendaciones.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
recomendaciones.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recomendaciones.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
    const recomendacionesForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recomendaciones.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::recomendaciones
 * @see app/Http/Controllers/CrmAiController.php:82
 * @route '/crm/ai/cliente/{cliente}/recomendaciones'
 */
        recomendacionesForm.post = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recomendaciones.url(args, options),
            method: 'post',
        })
    
    recomendaciones.form = recomendacionesForm
/**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
export const contactar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contactar.url(options),
    method: 'get',
})

contactar.definition = {
    methods: ["get","head"],
    url: '/crm/ai/contactar-hoy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
contactar.url = (options?: RouteQueryOptions) => {
    return contactar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
contactar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contactar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
contactar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contactar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
    const contactarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contactar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
        contactarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contactar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAiController::contactar
 * @see app/Http/Controllers/CrmAiController.php:90
 * @route '/crm/ai/contactar-hoy'
 */
        contactarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contactar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contactar.form = contactarForm
/**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
export const insight = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: insight.url(args, options),
    method: 'get',
})

insight.definition = {
    methods: ["get","head"],
    url: '/crm/ai/cliente/{cliente}/insight',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
insight.url = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cliente: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cliente: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cliente: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cliente: typeof args.cliente === 'object'
                ? args.cliente.id
                : args.cliente,
                }

    return insight.definition.url
            .replace('{cliente}', parsedArgs.cliente.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
insight.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: insight.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
insight.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: insight.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
    const insightForm = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: insight.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
        insightForm.get = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: insight.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CrmAiController::insight
 * @see app/Http/Controllers/CrmAiController.php:99
 * @route '/crm/ai/cliente/{cliente}/insight'
 */
        insightForm.head = (args: { cliente: string | number | { id: string | number } } | [cliente: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: insight.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    insight.form = insightForm
const ai = {
    procesar: Object.assign(procesar, procesar),
cliente: Object.assign(cliente, cliente),
recomendaciones: Object.assign(recomendaciones, recomendaciones),
contactar: Object.assign(contactar, contactar),
insight: Object.assign(insight, insight),
agent: Object.assign(agent, agent),
}

export default ai