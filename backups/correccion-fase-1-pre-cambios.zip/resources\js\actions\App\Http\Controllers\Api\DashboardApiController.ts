import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
export const stats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/api/v1/dashboard/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
stats.url = (options?: RouteQueryOptions) => {
    return stats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
stats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
stats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
    const statsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
        statsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
        statsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stats.form = statsForm
/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
export const ventasPorMes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasPorMes.url(options),
    method: 'get',
})

ventasPorMes.definition = {
    methods: ["get","head"],
    url: '/api/v1/dashboard/ventas-mes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
ventasPorMes.url = (options?: RouteQueryOptions) => {
    return ventasPorMes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
ventasPorMes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasPorMes.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
ventasPorMes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ventasPorMes.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
    const ventasPorMesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ventasPorMes.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
        ventasPorMesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasPorMes.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasPorMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
        ventasPorMesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasPorMes.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ventasPorMes.form = ventasPorMesForm
/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
export const topProductos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: topProductos.url(options),
    method: 'get',
})

topProductos.definition = {
    methods: ["get","head"],
    url: '/api/v1/dashboard/top-productos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
topProductos.url = (options?: RouteQueryOptions) => {
    return topProductos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
topProductos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: topProductos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
topProductos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: topProductos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
    const topProductosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: topProductos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
        topProductosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: topProductos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
        topProductosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: topProductos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    topProductos.form = topProductosForm
const DashboardApiController = { stats, ventasPorMes, topProductos }

export default DashboardApiController