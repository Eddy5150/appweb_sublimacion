import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/productos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ProductoApiController::index
 * @see app/Http/Controllers/Api/ProductoApiController.php:17
 * @route '/api/v1/productos'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ProductoApiController::store
 * @see app/Http/Controllers/Api/ProductoApiController.php:37
 * @route '/api/v1/productos'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/productos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::store
 * @see app/Http/Controllers/Api/ProductoApiController.php:37
 * @route '/api/v1/productos'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::store
 * @see app/Http/Controllers/Api/ProductoApiController.php:37
 * @route '/api/v1/productos'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::store
 * @see app/Http/Controllers/Api/ProductoApiController.php:37
 * @route '/api/v1/productos'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::store
 * @see app/Http/Controllers/Api/ProductoApiController.php:37
 * @route '/api/v1/productos'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
export const show = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/productos/{producto}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
show.url = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { producto: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { producto: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    producto: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        producto: typeof args.producto === 'object'
                ? args.producto.id
                : args.producto,
                }

    return show.definition.url
            .replace('{producto}', parsedArgs.producto.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
show.get = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
show.head = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
    const showForm = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
        showForm.get = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ProductoApiController::show
 * @see app/Http/Controllers/Api/ProductoApiController.php:30
 * @route '/api/v1/productos/{producto}'
 */
        showForm.head = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
export const update = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/v1/productos/{producto}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
update.url = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { producto: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { producto: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    producto: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        producto: typeof args.producto === 'object'
                ? args.producto.id
                : args.producto,
                }

    return update.definition.url
            .replace('{producto}', parsedArgs.producto.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
update.put = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
update.patch = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
    const updateForm = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
        updateForm.put = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Api\ProductoApiController::update
 * @see app/Http/Controllers/Api/ProductoApiController.php:56
 * @route '/api/v1/productos/{producto}'
 */
        updateForm.patch = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\ProductoApiController::destroy
 * @see app/Http/Controllers/Api/ProductoApiController.php:75
 * @route '/api/v1/productos/{producto}'
 */
export const destroy = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/productos/{producto}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::destroy
 * @see app/Http/Controllers/Api/ProductoApiController.php:75
 * @route '/api/v1/productos/{producto}'
 */
destroy.url = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { producto: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { producto: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    producto: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        producto: typeof args.producto === 'object'
                ? args.producto.id
                : args.producto,
                }

    return destroy.definition.url
            .replace('{producto}', parsedArgs.producto.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::destroy
 * @see app/Http/Controllers/Api/ProductoApiController.php:75
 * @route '/api/v1/productos/{producto}'
 */
destroy.delete = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::destroy
 * @see app/Http/Controllers/Api/ProductoApiController.php:75
 * @route '/api/v1/productos/{producto}'
 */
    const destroyForm = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::destroy
 * @see app/Http/Controllers/Api/ProductoApiController.php:75
 * @route '/api/v1/productos/{producto}'
 */
        destroyForm.delete = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
export const variantes = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: variantes.url(args, options),
    method: 'get',
})

variantes.definition = {
    methods: ["get","head"],
    url: '/api/v1/productos/{producto}/variantes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
variantes.url = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { producto: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { producto: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    producto: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        producto: typeof args.producto === 'object'
                ? args.producto.id
                : args.producto,
                }

    return variantes.definition.url
            .replace('{producto}', parsedArgs.producto.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
variantes.get = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: variantes.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
variantes.head = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: variantes.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
    const variantesForm = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: variantes.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
        variantesForm.get = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: variantes.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ProductoApiController::variantes
 * @see app/Http/Controllers/Api/ProductoApiController.php:84
 * @route '/api/v1/productos/{producto}/variantes'
 */
        variantesForm.head = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: variantes.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    variantes.form = variantesForm
/**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
export const imagenes = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: imagenes.url(args, options),
    method: 'get',
})

imagenes.definition = {
    methods: ["get","head"],
    url: '/api/v1/productos/{producto}/imagenes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
imagenes.url = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { producto: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { producto: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    producto: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        producto: typeof args.producto === 'object'
                ? args.producto.id
                : args.producto,
                }

    return imagenes.definition.url
            .replace('{producto}', parsedArgs.producto.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
imagenes.get = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: imagenes.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
imagenes.head = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: imagenes.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
    const imagenesForm = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: imagenes.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
        imagenesForm.get = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: imagenes.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ProductoApiController::imagenes
 * @see app/Http/Controllers/Api/ProductoApiController.php:89
 * @route '/api/v1/productos/{producto}/imagenes'
 */
        imagenesForm.head = (args: { producto: string | number | { id: string | number } } | [producto: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: imagenes.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    imagenes.form = imagenesForm
const ProductoApiController = { index, store, show, update, destroy, variantes, imagenes }

export default ProductoApiController