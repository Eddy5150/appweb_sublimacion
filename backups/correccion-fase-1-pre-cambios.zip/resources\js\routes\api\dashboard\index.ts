import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
export const stats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/api/v1/dashboard/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
stats.url = (options?: RouteQueryOptions) => {
    return stats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
stats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
stats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
    const statsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
        statsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardApiController::stats
 * @see app/Http/Controllers/Api/DashboardApiController.php:15
 * @route '/api/v1/dashboard/stats'
 */
        statsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stats.form = statsForm
/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
export const ventasMes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasMes.url(options),
    method: 'get',
})

ventasMes.definition = {
    methods: ["get","head"],
    url: '/api/v1/dashboard/ventas-mes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
ventasMes.url = (options?: RouteQueryOptions) => {
    return ventasMes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
ventasMes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ventasMes.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
ventasMes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ventasMes.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
    const ventasMesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ventasMes.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
        ventasMesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasMes.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardApiController::ventasMes
 * @see app/Http/Controllers/Api/DashboardApiController.php:47
 * @route '/api/v1/dashboard/ventas-mes'
 */
        ventasMesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ventasMes.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ventasMes.form = ventasMesForm
/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
export const topProductos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: topProductos.url(options),
    method: 'get',
})

topProductos.definition = {
    methods: ["get","head"],
    url: '/api/v1/dashboard/top-productos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
topProductos.url = (options?: RouteQueryOptions) => {
    return topProductos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
topProductos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: topProductos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
topProductos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: topProductos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
    const topProductosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: topProductos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
        topProductosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: topProductos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardApiController::topProductos
 * @see app/Http/Controllers/Api/DashboardApiController.php:62
 * @route '/api/v1/dashboard/top-productos'
 */
        topProductosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: topProductos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    topProductos.form = topProductosForm
const dashboard = {
    stats: Object.assign(stats, stats),
ventasMes: Object.assign(ventasMes, ventasMes),
topProductos: Object.assign(topProductos, topProductos),
}

export default dashboard